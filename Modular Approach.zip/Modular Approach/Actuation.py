import serial
import math
import numpy as np
from time import sleep
import os

arduino = serial.Serial("/dev/ttyACM0", 9600, timeout=1)

L1 = 1
L2 = 1


def drive(L, R):
    L = L / 2 + 50
    R = R / 2 + 50
    arduino.write(("D" + str(L) + str(R) + "\n").encode("utf-8"))


class joint:
    def __init__(self, name, pos):
        self.pos = pos
        self.name = name

    def rotate(self, angle):
        arduino.write((str(self.name) + str(angle).zfill(3) + "\n").encode("utf-8"))
        self.pos = angle


##### Servos #####
LS = joint(name="LS", pos=90)
LT = joint(name="LT", pos=90)
LE = joint(name="LE", pos=90)
LW = joint(name="LW", pos=90)
RS = joint(name="RS", pos=90)
RT = joint(name="RT", pos=90)
RE = joint(name="RE", pos=90)
RW = joint(name="RW", pos=90)
NP = joint(name="NP", pos=90)
NT = joint(name="NT", pos=90)

##### Leaning Joints #####
LF = joint(name="LF", pos=0)
LL = joint(name="LL", pos=0)


def in_motion():
    arduino.reset_input_buffer()  #################
    arduino.write("inMotion\n".encode("utf-8"))
    while not arduino.in_waiting > 0:
        sleep(0.01)
    data = arduino.readline().decode("utf-8").rstrip()
    if data == "true":
        return True
    else:
        return False


def speak(message):
    os.system('espeak "' + message + '"')
